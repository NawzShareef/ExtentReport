package utils;

import com.aventstack.extentreports.Status;
import io.cucumber.plugin.EventListener;
import io.cucumber.plugin.event.EventPublisher;
import io.cucumber.plugin.event.PickleStepTestStep;
import io.cucumber.plugin.event.TestStepStarted;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;


import static steps.MakeMyTripHotel_Steps.currentStep;

public class hooks implements EventListener {
    private static final Logger logger = LogManager.getLogger(hooks.class);

    @Before
    public void beforeScenario(Scenario scenario) {
        logger.info("Starting scenario: " + scenario.getName());
        GenerateReport.startTest(scenario.getName());
        GenerateReport.log(Status.INFO, "Scenario started: " + scenario.getName());
    }

    @After
    public void afterScenario(Scenario scenario) {
        logger.info("Ending scenario: " + scenario.getName());

        if (scenario.isFailed()) {
            GenerateReport.log(Status.FAIL, "Scenario failed: " + scenario.getName());
        } else {
            GenerateReport.log(Status.PASS, "Scenario passed: " + scenario.getName());
        }

        GenerateReport.flush();
    }

    @Override
    public void setEventPublisher(EventPublisher publisher) {
        publisher.registerHandlerFor(TestStepStarted.class, this::handleTestStepStarted);
    }

    private void handleTestStepStarted(TestStepStarted event) {
        if (event.getTestStep() instanceof PickleStepTestStep) {
            PickleStepTestStep testStep = (PickleStepTestStep) event.getTestStep();
            currentStep = testStep.getStep().getText();
        }
    }
}
