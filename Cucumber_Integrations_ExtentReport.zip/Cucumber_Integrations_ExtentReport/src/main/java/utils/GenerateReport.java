package utils;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.File;

public class GenerateReport {
    private static final Logger logger = LogManager.getLogger(GenerateReport.class);
    private static ExtentReports reports;
    private static ExtentTest test;

    public static void setup() {
        // Create the reports directory if it doesn't exist
        File reportDir = new File("target/reports");
        if (!reportDir.exists()) {
            reportDir.mkdirs();
            logger.info("Created reports directory: " + reportDir.getPath());
        } else {
            logger.info("Reports directory already exists: " + reportDir.getPath());
        }

        // Initialize ExtentReports and attach the HTML reporter
        ExtentSparkReporter spark = new ExtentSparkReporter("target/reports/TestReport.html");
        reports = new ExtentReports();
        reports.attachReporter(spark);
        logger.info("Initialized ExtentReports with HTML reporter.");
    }

    public static void startTest(String testName) {
        test = reports.createTest(testName);
        logger.info("Started test: " + testName);
    }

    public static ExtentTest getTest() {
        return test;
    }

    public static void log(Status status, String details) {
        if (test != null) {
            test.log(status, details);
            logger.info("Logged to ExtentTest: " + status + " - " + details);
        } else {
            logger.warn("No active test. Cannot log to ExtentTest.");
        }
    }

    public static void flush() {
        // This method writes the test information to the report file
        if (reports != null) {
            reports.flush();
            logger.info("Flushed ExtentReports.");
        } else {
            logger.warn("ExtentReports is null. Cannot flush.");
        }
    }
}
