package steps;

import actions.GlobalWait;
import framework.Configuration;
import framework.Driver;
import io.cucumber.java.*;
import io.github.bonigarcia.wdm.WebDriverManager;
import lombok.var;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import utils.GenerateReport;

import java.util.Base64;

import static steps.MakeMyTripHotel_Steps.currentStep;

public class Driver_Steps {

    WebDriver driver;

    @Before
    public void setUp() throws Exception {
        WebDriverManager.chromedriver().setup();
        DesiredCapabilities cap = new DesiredCapabilities();
        Driver.add(Configuration.get("browser"), cap);
        driver = Driver.current();
        driver.get(Configuration.get("url"));
        driver.manage().window().maximize();
        GlobalWait.setDriver(driver);
    }

    @AfterStep
    public void tearDown(Scenario scenario) {
        byte[] screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
        String base64Screenshot = Base64.getEncoder().encodeToString(screenshot);

        // Create a test node for the step
        var testNode = GenerateReport.getTest().createNode(currentStep);

        if (scenario.isFailed()) {
            scenario.attach(screenshot, "image/png", "Failed Screenshot");
            testNode.fail("Step failed")
                    .addScreenCaptureFromBase64String(base64Screenshot);
        } else {
            scenario.attach(screenshot, "image/png", "Passed Screenshot");
            testNode.pass("Step passed")
                    .addScreenCaptureFromBase64String(base64Screenshot);
        }

        GenerateReport.flush();
    }

    public WebDriver getDriver() {
        return driver;
    }
}
