package TestRunner;

import org.junit.BeforeClass;
import org.junit.runner.RunWith;
import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import utils.GenerateReport;

@RunWith(Cucumber.class)
@CucumberOptions(
        features = "src/test/java/features/makemytrip.feature",
        glue = {"steps", "actions", "utils"},
        plugin = {"pretty", "json:target/cucumber.json"}
)
public class TestRunner {

    @BeforeClass
    public static void setup() {
        GenerateReport.setup();
    }
}
